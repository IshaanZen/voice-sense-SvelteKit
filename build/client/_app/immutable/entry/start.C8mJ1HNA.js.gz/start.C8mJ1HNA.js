import{c as a}from"../chunks/entry.DrlEW8Lw.js";export{a as start};
