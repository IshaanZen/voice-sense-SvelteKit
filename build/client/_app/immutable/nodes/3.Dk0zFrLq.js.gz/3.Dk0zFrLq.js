import{s}from"../chunks/scheduler.DsWiACDR.js";import{S as t,i as e}from"../chunks/index.B0pGoJ8j.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
